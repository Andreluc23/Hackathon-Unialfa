<?php
require_once '../src/api.php';

// Consome a API Node.js para buscar alunos com eventos
$alunosComEventos = fazerRequisicao('http://localhost:3002/alunos/eventos-com-alunos');

if (!is_array($alunosComEventos)) {
    $alunosComEventos = [];
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <title>Certificados - UniALFA Eventos</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
  <link rel="stylesheet" href="../css/style.css">

</head>
<body>

<?php include('../templates/header.php'); ?>

<main>
  <h1 class="certificado-titulo"> Certificados Emitidos</h1>

  <?php if (empty($alunosComEventos)): ?>
    <p class="nenhum">Nenhuma inscrição encontrada para emissão de certificados.</p>
  <?php else: ?>
    <div class="table-container">
      <table class="table table-striped table-bordered align-middle text-center">
        <thead class="table-dark">
          <tr>
            <th>Nome</th>
            <th>RA</th>
            <th>Evento</th>
            <th>Certificado</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($alunosComEventos as $aluno): ?>
            <tr>
              <td><?= htmlspecialchars($aluno['nome']); ?></td>
              <td><?= htmlspecialchars($aluno['matricula_ra']); ?></td>
              <td><?= htmlspecialchars($aluno['evento']['nome'] ?? 'Evento não encontrado'); ?></td>
              <td>
                <a href="http://localhost:3002/certificado/<?= $aluno['aluno_id']; ?>" class="btn-certificado" target="_blank">
                  Visualizar
                </a>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</main>

<?php include('../templates/footer.php'); ?>

</body>
</html>
